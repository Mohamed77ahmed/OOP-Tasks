﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3.Authentications
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }

        public User(string username, string password, string role)
        {
            Username = username;
            Password = password;
            Role = role;
        }
    }




    public class BasicAuthenticationService : IAuthenticationService
    {
        private readonly List<User> users = new()
        {
            new User("admin", "1234", "Administrator"),
            new User("user", "abcd", "StandardUser")
        };

        public bool AuthenticateUser(string username, string password)
        {
            foreach (var user in users)
            {
                if (user.Username == username && user.Password == password)
                    return true;
            }
            return false;
        }

        public bool AuthorizeUser(string username, string role)
        {
            foreach (var user in users)
            {
                if (user.Username == username && user.Role == role)
                    return true;
            }
            return false;
        }
    }
}




