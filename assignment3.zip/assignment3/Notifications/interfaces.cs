﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3.Notifications
{
    public interface INotificationService
    {
        void SendNotification(string recipient, string message);
    }
}
