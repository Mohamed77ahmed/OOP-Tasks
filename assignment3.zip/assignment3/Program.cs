﻿using assignment3.Authentications;
using assignment3.Notifications;
using assignment3.Shapes;
using System.Data;
using System.Runtime.Intrinsics.X86;

namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {

            #region part1

            //            What is the primary purpose of an interface in C#?
            //a) To provide a way to implement multiple inheritance
            //b) To define a blueprint for a class                                       //A
            //c) To declare abstract methods and properties
            //d) To create instances of objects



            //            Question 2:
            //Which of the following is NOT a valid access modifier for interface members in C#?
            //a) private
            //b) protected                                                                          //A
            //c) internal
            //d) public






            //            Question 3:
            //Can an interface contain fields in C#?
            //a) Yes                                                            //B
            //b) No
            //c) Only if they are static
            //d) Only if they are readonly





//            Question 4:
//In C#, can an interface inherit from another interface?
//a) No, interfaces cannot inherit from each other
//b) Yes, interfaces can inherit from multiple interfaces                //B
//c) Yes, but only if they have the same methods
//d) Only if the interfaces are in the same namespace




//Question 5:
//Which keyword is used to implement an interface in a class in C#?
//a) inherit
//b) use                                                     //D
//c) extends
//d) implements



//Question 6:
//Can an interface contain static methods in C#?
//a) Yes
//b) No
//c) Only if the interface is sealed                 //A
//d) Only if the methods are private



//Question 7:
//In C#, can an interface have explicit access modifiers for its members?
//a) Yes, for all members
//b) No, all members are implicitly public
//c) Yes, but only for abstract members                                        //B
//d) Only if the interface is sealed




//Question 8:
//What is the purpose of an explicit interface implementation in C#?
//a) To hide the interface members from outside access
//b) To provide a clear separation between interface and class members
//c) To allow multiple classes to implement the same interface
//d) To speed up method resolution


//Question 9:
//In C#, can an interface have a constructor?
//a) Yes, but it must be private
//b) No, interfaces cannot have constructors               //B
//c) Yes, but only if the interface is sealed
//d) Only if the constructor is static

//Question 10:
//How can a C# class implement multiple interfaces?
//a) By using the "implements" keyword
//b) By using the "extends" keyword
//c) By separating interface names with commas             //C
//d) A class cannot implement multiple interfaces











    #endregion


    #region question 1


    //Circle circle = new Circle(5);
    //circle.DisplayShapeInfo();
    //Rectangle rectangle = new Rectangle(2,5);
    //rectangle
    //    .DisplayShapeInfo();
    #endregion


    #region question2

    //BasicAuthenticationService basicauthen=new BasicAuthenticationService();
    // User user = new User("ahmed","123","admin");

    //if (basicauthen.AuthenticateUser(user.Username, user.Password))
    //{
    //    Console.WriteLine("User authenticated.");

    //    if (basicauthen.AuthorizeUser(user.Username, user.Role))
    //    {
    //        Console.WriteLine($"User authorized as {user.Role}.");
    //    }
    //    else
    //    {
    //        Console.WriteLine("User not authorized.");
    //    }
    //}
    //else
    //{
    //    Console.WriteLine("Authentication failed.");
    //}

    #endregion



    #region question3
    //INotificationService emailService = new EmailNotificationService();
    //INotificationService smsService = new SmsNotificationService();
    //INotificationService pushService = new PushNotificationService();

    //string recipient = "user@example.com";
    //string message = "Hello! This is a test notification.";

    //emailService.SendNotification(recipient, message);
    //smsService.SendNotification("0123456789", "Hello from SMS");
    //pushService.SendNotification("device_123", "Push");


    #endregion
    }
}
}
