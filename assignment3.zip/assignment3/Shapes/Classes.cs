﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3.Shapes
{
    public class Circle : ICircle
    {

        public decimal area { get; set; }
        public int radius { get ; set ; }

        public Circle(int _radius)
        {
         radius = _radius ; 
            area= _radius*_radius*3.14m ;
        }
       


        public void DisplayShapeInfo()
        {
            Console.WriteLine("shape is circle");
            Console.WriteLine($"radius  {radius}, area : {area}");
            
        }
    }




    public class Rectangle : IRectangle
    {
        public int width { get; set; }
        public int length { get; set; }
        public decimal area { get; set; }

        public Rectangle(int _length ,int _width)
        {
            length = _length ;
            width = _width ;
            area = _length * _width;
        }
        public void DisplayShapeInfo()
        {
            Console.WriteLine("shape is rectangle");
            Console.WriteLine($"length  {length}, width : {width} , area : {area}" );
        }
    }


}
