﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3.Shapes
{
    internal interface Ishape
    {
        public decimal area { get; set; }

        public void DisplayShapeInfo();
    }


    internal interface IRectangle:Ishape
    {
       
    }
    internal interface ICircle : Ishape 
    {

    }
}
